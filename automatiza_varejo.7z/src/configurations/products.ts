export default [
	{ name: 'NPS', description: 'Avaliação de Empresas' },
	{ name: 'PRODUCT 2', description: 'DESCRIÇÃO DO PRODUTO 2' },
	{ name: 'PRODUCT 3', description: 'DESCRIÇÃO DO PRODUTO 3' }
]