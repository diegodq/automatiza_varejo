export const responsesTests = [
	{ company: 'AUTOMATIZA SOLUÇÕES PARA O VAREJO LTDA' },
	{ header: 'AUTOMATIZA SOLUÇÕES PARA O VAREJO LTDA' },
	{ period: 'AUTOMATIZA SOLUÇÕES PARA O VAREJO LTDA' },
	{
		questionAndResponses: [
			"Quantas vezes por semana você frequenta nosso estabelecimento",
			"2",
			"Qal departamento você mais gostou em nossa loja?",
			"GERÊNCIA",
			"Qal departamento você mais gostou em nossa loja?",
			"DEPÓSITO",
		]
	},
	{ tree: 0 }
];