class CreateQrCodeService
{
	public async execute()
	{
		return 'Service to generate a new QRCode';
	}
}

export default CreateQrCodeService;